package com.example.growingmobilef1.Interface;

public interface IListableObject {

    int getmId();

    String getmMainInformation();

    String getmOptionalInformation();

    String getmSecondaryInformation();

    Boolean isButtonRequired();
}
